module.exports = app => {
    app.locals.siteTitle = 'IronJob'
}
